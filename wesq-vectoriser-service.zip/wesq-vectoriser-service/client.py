# 3: Query the deployment and print the results.
import requests

print(requests.get("http://127.0.0.1:8000/hello", params={"name": "Theodore"}).json())
# "Hello Theodore!"
#
# print(requests.get("http://localhost:8000/health").json())
# # {"status": "up"}
#
# print(requests.get("http://localhost:8000/").text)
# # "vecto svc"