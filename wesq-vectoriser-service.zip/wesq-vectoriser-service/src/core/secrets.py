import os
import re

if os.environ.get('ENVIRONMENT') == 'local':
    from src.core.vault_local import get_secret
    ENV = "dev-1"
    AWS_REGION = "eu-west-1"

else:
    from wesqhelper.vault_auth import get_secret

    ENV = os.environ.get('ENVIRONMENT')
    AWS_REGION = os.environ.get('AWS_REGION')


app_secrets = get_secret()


class Config:
    SCHEMA_NAME = "fact_finding_data"
    DB_NAME = f"{ENV}-wpapp"
    DB_USER = app_secrets['postgres']['username']
    DB_PASS = app_secrets['postgres']['password']
    DB_HOST = app_secrets['postgres']['address']
    DB_PORT = app_secrets['postgres']['port']
    SQLALCHEMY_DATABASE_URI = f"""postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"""



"""environment wrt wesq"""
ENVIRONMENT = ENV
PROJECT = "wp"




"""KAFKA TOPIC"""
topic_request = f"{PROJECT}-{ENVIRONMENT}.transcript-file-uploaded.{AWS_REGION}"

