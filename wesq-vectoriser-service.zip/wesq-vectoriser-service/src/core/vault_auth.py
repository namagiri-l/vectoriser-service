import os
import hvac
from hvac.api.auth_methods import Kubernetes

vaultAddr = os.environ['VAULT_ADDRESS']
vaultPath = os.environ['VAULT_DATA_PATH']
vaultPaths = os.environ['VAULT_PATHS']
authMount = os.environ['VAULT_AUTH_PATH']
authRole = os.environ['VAULT_AUTH_ROLE']


def get_secret():
    f = open('/var/run/secrets/kubernetes.io/serviceaccount/token')
    jwt = f.read()
    # print("jwt:", jwt)
    f.close()
    client = hvac.Client(url=vaultAddr, verify='./ca.crt')
    # client.auth_kubernetes(authRole, jwt, mount_point=authMount)
    Kubernetes(client.adapter).login(
        role=authRole,
        jwt=jwt, mount_point=authMount
    )
    creds = {}
    finalpath = vaultPaths.split(",")
    finalpath.append(vaultPath)
    for paths in finalpath:
        try:
            keys = client.secrets.kv.v1.read_secret(
                path=paths.split("/", 1)[1],
                mount_point=paths.split("/")[0],
            )['data']
            creds[paths.split("/")[len(paths.split("/")) - 1]] = keys
        except:
            pass
    return creds