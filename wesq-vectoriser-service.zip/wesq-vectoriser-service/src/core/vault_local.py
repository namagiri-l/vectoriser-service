
def get_secret():
    creds = {
        "postgres": {
            "username": "postgres",
            "password": "nLOlKR0LdOYZOW9yTeODuAUGeLMMWKNRpxUlAp7Aj66YLAHdN1pZRSPi8O9ZFB2b",
            "address": "main.ops.pg.ovh.dlt",
            "port": "5432"
        },
        "milvus": {
            "host": "terraaimilvus-milvus.services-terraai.svc.cluster.local",
            "password": "dev_terraai",
            "port": "19530",
            "username": "dev_terraai",
            "db_name": "wesq_query_engine"
        }
    }
    return creds

