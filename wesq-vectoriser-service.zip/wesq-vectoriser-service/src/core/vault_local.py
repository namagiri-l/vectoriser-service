def get_secret():
    creds = {
        "postgres": {
            "username": "postgres",
            "password": "nLOlKR0LdOYZOW9yTeODuAUGeLMMWKNRpxUlAp7Aj66YLAHdN1pZRSPi8O9ZFB2b",
            "address": "main.ops.pg.ovh.dlt",
            "port": "5432"
        }
    }
    return creds