from pydantic import BaseModel
from enum import Enum


class ClientTableModel(BaseModel):
    id: int
    name: str
    age: int
    address: str
    email: str
    phone: str
    created_at: str
    updated_at: str
    deleted_at: str
    status: Enum("ACTIVE", "INACTIVE")


class ClientModel(BaseModel):
    operation: Enum("INSERT", UPDATE, DELETE)
    data: ClientTableModel


