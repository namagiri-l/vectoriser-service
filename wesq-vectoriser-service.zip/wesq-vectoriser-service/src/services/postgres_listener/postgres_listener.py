import asyncio
from wesqhelper.log_config import logger
from ray import serve
from ray.serve.handle import DeploymentHandle
from src.utils.listener import PostgresListener

@serve.deployment
class RunDeployment:
    def __init__(self, channels):
        self.listeners = [PostgresListener(channel) for channel in channels]
        logger.info("Listeners initialized for channels: %s", channels)

    async def run(self):
        try:
            while True:
                for listener in self.listeners:
                    async for pid, channel, payload in listener.check_notifications():
                        logger.debug(f"Yielding notification from channel {channel}: {payload}")
                        yield pid, channel, payload
                await asyncio.sleep(1)  # Delay to reduce CPU usage
        except KeyboardInterrupt:
            logger.info("Shutting down listeners...")
            for listener in self.listeners:
                listener.stop()
            logger.info("All listeners shut down.")

    async def __call__(self, *args, **kwargs):
        logger.info("Listener started")
        async for notification in self.run():
            logger.info(f"Received notification: {notification}")
        logger.info("Listener stopped")

channels = [
    'retirement_planning_data_changes',
    'cash_asset_data_changes',
    'dependent_school_information_data_changes',
    'employee_benefit_data_changes',
    'expenditure_data_changes',
    'fact_find_data_changes',
    'health_data_changes',
    'income_data_changes',
    'inheritance_notes_data_changes',
    'inheritance_tax_planning_data_changes',
    'insurance_data_changes',
    'investment_asset_data_changes',
    'investment_experience_data_changes',
    'liability_data_changes',
    'pension_asset_data_changes',
    'priority_matrix_data_changes',
    'property_asset_data_changes',
    'investment_solution_data_changes',
    'protection_solution_data_changes',
    'advisor_note_data_changes',
    'personal_pii_details_data_changes',
    'investor_relationship_data_changes',
    'beneficiary_data_changes',
    'investor_data_changes',
    'tax_residency_data_changes',
    'employment_data_changes'
]

@serve.deployment
class PostgresListenerDeployment:
    def __init__(self, run: DeploymentHandle):
        self.run = run.remote()

    async def __call__(self, *args, **kwargs):
        logger.info("Listener started")
        async for notification in self.run.options(stream=True):
            logger.info(f"Received notification: {notification}")


app = PostgresListenerDeployment.options(route_prefix="/listener").bind(RunDeployment.bind(channels))
