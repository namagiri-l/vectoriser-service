import psycopg2
import psycopg2.extensions
from wesqhelper.log_config import logger
from src.core.secrets import Config

class PostgresListener:
    def __init__(self, channel):
        self.channel = channel
        self.connection = psycopg2.connect(dsn=Config.SQLALCHEMY_DATABASE_URI)
        self.connection.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        self.cursor = self.connection.cursor()
        self.cursor.execute(f"LISTEN {self.channel};")
        # logger.info(f"Listening on channel {self.channel}")

    async def check_notifications(self):
        self.connection.poll()
        while self.connection.notifies:
            notify = self.connection.notifies.pop(0)
            logger.debug(f"Received notification, yielding: {notify.pid}, {notify.channel}, {notify.payload}")
            yield notify.pid, notify.channel, notify.payload

    def stop(self):
        self.cursor.close()
        self.connection.close()
        logger.info(f"Stopped listening on channel {self.channel}")
