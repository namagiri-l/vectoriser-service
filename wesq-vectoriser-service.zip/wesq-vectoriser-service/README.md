#steps for running
serve build main:binding_app src.services.postgres_listener.postgres_listener:app -o config.yaml
serve config.yaml