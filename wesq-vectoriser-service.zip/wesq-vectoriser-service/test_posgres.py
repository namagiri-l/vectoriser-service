import asyncio
import asyncpg
from wesqhelper.log_config import logger
from core.secrets import SQLALCHEMY_DATABASE_URI
async def listen_notifications():
    conn = await asyncpg.connect(dsn=SQLALCHEMY_DATABASE_URI)
    await conn.add_listener('fact_data_channel', handle_notification)
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await conn.close()

async def handle_notification(connection, pid, channel, payload):
    logger.info(f"Got NOTIFY: {pid}, {channel}, {payload}")


