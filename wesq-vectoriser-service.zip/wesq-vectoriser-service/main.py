import ray
from fastapi import FastAPI
from ray import serve

# ray.init(ignore_reinit_error=True)

app = FastAPI()


@serve.deployment
@serve.ingress(app)
class FastAPIDeployment:


    @app.get("/health")
    def health(self) -> dict:
        return {"status": "up"}

    @app.get("/")
    def root(self) -> str:
        return "WESQ Vectoriser service"





serve.start()
binding_app = FastAPIDeployment.bind()


# if __name__ == "__main__":
# import uvicorn
# serve.run(binding_app,route_prefix='/')
# uvicorn.run(app, host="0.0.0.0", port=8000)
