from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from kubernetes import client, config
from kubernetes.client.rest import ApiException
import yaml

app = FastAPI()

# Load the kubeconfig file
config.load_kube_config()

@app.post("/apply-yaml/")
async def apply_yaml(file: UploadFile = File(...)):
    try:
        # Read the uploaded YAML file
        contents = await file.read()
        pod_manifest = yaml.safe_load(contents)

        # Create an instance of the API class
        v1 = client.CoreV1Api()

        # Apply the YAML configuration
        api_response = v1.create_namespaced_pod(
            body=pod_manifest,
            namespace='default')
        return JSONResponse(status_code=200, content={"message": "Pod created", "status": str(api_response.status)})
    except ApiException as e:
        return JSONResponse(status_code=500, content={"message": "Exception when calling CoreV1Api->create_namespaced_pod", "error": str(e)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"message": "An error occurred", "error": str(e)})
